import {readFileSync} from 'node:fs';
import { beforeAll, afterAll, beforeEach, afterEach, it, expect } from 'vitest';
import { freshDatabase } from './fixtures/schema';
import { sampleState } from './fixtures/centre';
import { buildWorkbook } from '../src/lib/workbook';
import { shiftKey } from '../src/lib/domain';
let db: Awaited<ReturnType<typeof freshDatabase>>;
const o='10000000-0000-0000-0000-000000000001', o2='10000000-0000-0000-0000-000000000002';
const t='20000000-0000-0000-0000-000000000001', t2='20000000-0000-0000-0000-000000000002';
const a='30000000-0000-0000-0000-000000000001', b='30000000-0000-0000-0000-000000000002', m='30000000-0000-0000-0000-000000000003';
const c='40000000-0000-0000-0000-000000000001', s='60000000-0000-0000-0000-000000000001', sh='70000000-0000-0000-0000-000000000001';
const endpoint='https://fcm.googleapis.com/audit-device';
async function user(id:string) { await db.exec('reset role'); await db.query("select set_config('request.jwt.claim.sub',$1,false)",[id]); await db.exec('set role authenticated'); }
async function service() { await db.exec('reset role; set role service_role'); }
async function register(){ await db.query("select public.register_push_subscription($1,$2,$3)",[endpoint,'A'.repeat(87),'B'.repeat(22)]); }
beforeAll(async()=>{
 db=await freshDatabase(); await db.exec('alter table auth.users add column created_at timestamptz default now(), add column last_sign_in_at timestamptz;');
 await db.query("insert into auth.users(id,email,email_confirmed_at) values ($1,'a@example.test',now()),($2,'b@example.test',now()),($3,'m@example.test',now())",[a,b,m]);
 await db.query("insert into public.profiles(user_id,display_name,email) values ($1,'Agent A','a@example.test'),($2,'Agent B','b@example.test'),($3,'Manager','m@example.test')",[a,b,m]);
 await db.query("insert into public.organizations(id,name) values ($1,'Centre A'),($2,'Centre B')",[o,o2]);
 await db.query("insert into public.teams(id,organization_id,name) values ($1,$2,'Alpha'),($3,$4,'Bravo')",[t,o,t2,o2]);
 for(const [id,role] of [[a,'AGENT'],[b,'AGENT'],[m,'ADMIN']]) await db.query("insert into public.memberships(organization_id,user_id,team_id,role) values($1,$2,$3,$4)",[o,id,t,role]);
 await db.query("insert into public.availability_campaigns(id,organization_id,team_id,name,starts_on,ends_on,opens_at,closes_at) values($1,$2,$3,'Audit','2026-10-01','2026-10-01',now()-interval '1 day',now()+interval '1 day')",[c,o,t]);
 for(const id of [a,b]) await db.query("insert into public.campaign_participants(organization_id,campaign_id,user_id) values($1,$2,$3)",[o,c,id]);
 await db.query("insert into public.schedules(id,organization_id,campaign_id,team_id) values($1,$2,$3,$4)",[s,o,c,t]);
 await db.query("insert into public.schedule_shifts(id,organization_id,schedule_id,date,shift_code) values($1,$2,$3,'2026-10-01','DAY')",[sh,o,s]);
 await db.query("insert into public.staffing_requirements(organization_id,campaign_id,date,shift_code,headcount) values($1,$2,'2026-10-01','DAY',1)",[o,c]);
 for(const id of [a,b]) { await user(id); await db.query("insert into public.availability_entries(campaign_id,user_id,date,availability_type) values($1,$2,'2026-10-01','DAY')",[c,id]); await db.query("update public.campaign_participants set validated_at=now() where campaign_id=$1 and user_id=$2",[c,id]); }
 await db.exec('reset role');
},30000);
beforeEach(async()=>{await db.exec('reset role; begin');});
afterEach(async()=>{await db.exec('rollback; reset role');});
afterAll(async()=>{await db.close();});
it('R1: répéter le même abonnement efface la notification en attente',async()=>{
 await user(a); await register(); await db.exec('reset role');
 await db.query("insert into public.notifications(organization_id,user_id,kind,subject) values($1,$2,'SCHEDULE_PUBLISHED','Audit')",[o,a]);
 expect((await db.query('select * from public.push_deliveries')).rows).toHaveLength(1);
 await user(a); await register(); await db.exec('reset role');
 expect((await db.query('select * from public.push_deliveries')).rows).toHaveLength(0);
 expect((await db.query("select * from public.notifications where user_id=$1",[a])).rows.length).toBeGreaterThan(0);
});
it('R2: republier sans un agent ne lui crée aucune notification de retrait',async()=>{
 await user(m);
 for(const id of [a,b]) await db.query("insert into public.schedule_assignments(organization_id,schedule_shift_id,user_id,assigned_by) values($1,$2,$3,$4)",[o,sh,id,m]);
 await db.query("select public.publish_shift($1)",[sh]);
 await db.exec('reset role'); const before=(await db.query("select count(*)::int as n from public.notifications where user_id=$1",[a])).rows[0];
 await user(m); await db.query("delete from public.schedule_assignments where schedule_shift_id=$1 and user_id=$2 and revision=0",[sh,a]); await db.query("select public.publish_shift($1)",[sh]);
 await db.exec('reset role'); expect((await db.query("select count(*)::int as n from public.notifications where user_id=$1",[a])).rows[0]).toEqual(before);
 expect((await db.query("select * from public.schedule_assignments where schedule_shift_id=$1 and user_id=$2 and revision=2",[sh,a])).rows).toHaveLength(0);
});
it('R3 corrigé: Excel conserve une garde publiée retirée seulement du brouillon',()=>{
 const state=sampleState(new Date('2026-09-22T12:00:00Z')); const campaign=state.campaigns[0];
 state.assignments={}; state.publications={}; const key=shiftKey(campaign.id,'2026-10-01','DAY');
 state.publications[key]={agents:['julien'],revision:1,publishedAt:'2026-09-22T12:00:00Z'};
 state.assignments[key]=['marie'];
 const page=buildWorkbook(state,campaign).getWorksheet('Affectations')!;
 const values:string[]=[]; page.eachRow(row=>values.push(JSON.stringify(row.values)));
 expect(values.join(' ')).toContain('Julien Bernard'); expect(values.join(' ')).toContain('Marie Lambert');
});
it('R4: ancien centre conserve la modification du profil global après transfert',async()=>{
 await user(m); await db.query("update public.memberships set active=false where user_id=$1",[a]);
 await db.exec('reset role'); await db.query("insert into public.memberships values($1,$2,$3,'AGENT',true)",[o2,a,t2]);
 await user(m); const changed=await db.query("update public.profiles set display_name='Modifié par ancien centre' where user_id=$1 returning user_id",[a]); expect(changed.rows).toHaveLength(1);
 await user(a); expect((await db.query("select display_name from public.profiles where user_id=$1",[a])).rows[0]).toEqual({display_name:'Modifié par ancien centre'});
});
it('R5: une réservation email expirée est reprise mais le premier worker peut encore envoyer',async()=>{
 await db.query("insert into public.notifications(organization_id,user_id,kind,subject) values($1,$2,'SCHEDULE_PUBLISHED','Audit')",[o,a]);
 await service(); const first=(await db.query<{id:string;lease:string}>('select * from public.claim_email_deliveries(50)')).rows;
 expect(first.length).toBeGreaterThan(0);
 await db.exec("update public.notifications set email_available_at=now()-interval '1 second' where email_status='sending'");
 const second=(await db.query<{id:string;lease:string}>('select * from public.claim_email_deliveries(50)')).rows;
 const old=first[0], fresh=second.find(row=>row.id===old.id)!; expect(fresh.lease).not.toBe(old.lease);
 await db.query("select public.finish_email_delivery($1,$2,202)",[old.id,old.lease]);
 expect((await db.query("select email_status,email_lease from public.notifications where id=$1",[old.id])).rows[0]).toEqual({email_status:'sending',email_lease:fresh.lease});
});
it('R6 corrigé: les emails ne sont plus réservés après désactivation',async()=>{
 await db.query("insert into public.notifications(organization_id,user_id,kind,subject,body) values($1,$2,'SCHEDULE_PUBLISHED','Audit','Planning')",[o,a]);
 await user(m); await db.query("update public.memberships set active=false where user_id=$1",[a]);
 await service(); const jobs=(await db.query<{email:string}>('select * from public.claim_email_deliveries(50)')).rows; expect(jobs.some(row=>row.email==='a@example.test')).toBe(false);
});

it('C4 toujours présent: export RGPD du gestionnaire expose le téléphone d’un autre agent', async()=>{
 await user(m);
 await db.query("update public.profiles set phone='0600000099' where user_id=$1",[a]);
 await db.exec('reset role');
 const sql=readFileSync('supabase/provisioning/exporter-les-donnees-d-un-compte.sql','utf8').replaceAll('agent@exemple.fr','m@example.test');
 const exported=(await db.query<{donnees:string}>(sql)).rows[0].donnees;
 expect(exported).toContain('0600000099');
});

import {it,expect,vi} from 'vitest';
import React from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {sampleState} from './fixtures/centre';
import {coverage,shiftKey} from '../src/lib/domain';
const state=sampleState(new Date('2026-09-22T12:00:00Z'));
const campaign=state.campaigns[0];
vi.mock('next/navigation',()=>({useSearchParams:()=>new URLSearchParams('date=2026-10-01&shift=DAY')}));
vi.mock('../src/components/provider',()=>({useApp:()=>({state,campaign,campaignId:campaign.id,run:vi.fn()})}));
import {Planning} from '../src/components/planning';
it('R7 corrigé: un agent inactif affecté dispose du bouton Retirer',()=>{
 const inactive=state.agents.find(a=>a.id==='julien')!; state.agents=state.agents.filter(a=>a.id!==inactive.id);state.inactiveAgents=[inactive];
 state.assignments={[shiftKey(campaign.id,'2026-10-01','DAY')]:[inactive.id]};
 expect(coverage(state,campaign.id,'2026-10-01','DAY','planned').invalid.map(a=>a.id)).toContain(inactive.id);
 const html=renderToStaticMarkup(React.createElement(Planning));
 expect(html).toContain('Retirer Julien Bernard');
});

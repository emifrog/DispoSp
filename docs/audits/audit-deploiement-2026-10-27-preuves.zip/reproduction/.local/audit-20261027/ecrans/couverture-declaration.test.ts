import { describe, expect, it } from "vitest";
import { assign, sampleState } from "../../../tests/fixtures/centre";
import { coverage, shiftKey } from "../../../src/lib/domain";

/*
 * Analyse du 27 octobre 2026, B2.
 *
 * La base accepte une déclaration exceptionnelle retenue (proposition
 * `declared`, état SELECTED ou CONFIRMED) comme preuve de disponibilité :
 * `private.shift_blockers()` ne compte pas l'agent parmi les « disponibilité
 * qui ne correspond plus » (20261021090000_appels_remplacement.sql:278-284), et
 * tests/database.test.ts:7709 publie bien un tel agent.
 *
 * L'écran, lui, calcule sa couverture avec `coverage()` (src/lib/domain.ts),
 * qui ne lit jamais `state.callProposals` : l'agent retenu sur déclaration est
 * « invalide », la garde n'est pas « couverte », et « Confirmer et publier »
 * (calls.tsx, `disabled={!publishable}`) comme « Publier ce créneau »
 * (planning.tsx, `disabled={!result.covered}`) restent grisés.
 *
 * Ce test ÉCHOUE sur dc67d4d : c'est la preuve du défaut.
 */
const now = new Date("2026-09-18T10:00:00Z");
const campaignId = "campaign-2026-10";
const date = "2026-10-15";
const julien = "julien";

describe("Couverture d'une garde tenue sur déclaration exceptionnelle", () => {
  it("compte un candidat retenu sur déclaration comme disponible, comme la base le fait", () => {
    const state = sampleState(now);
    // Julien n'a rien saisi pour octobre : sans déclaration, il est « Plus
    // disponible sur ce créneau ».
    state.requirements[shiftKey(campaignId, date, "DAY")] = {
      ...state.requirements[shiftKey(campaignId, date, "DAY")],
      total: 1,
      qualifications: {},
    };
    assign(state, campaignId, date, "DAY", [julien]);
    const before = coverage(state, campaignId, date, "DAY", "planned");
    expect(before.invalid.map(a => a.id)).toContain(julien);
    expect(before.covered).toBe(false);

    // Un appel élargi sur cette garde, Julien s'est proposé en déclarant sa
    // disponibilité, et le gestionnaire l'a retenu : la base publierait.
    state.calls.push({
      id: "call-1",
      campaignId,
      shiftId: "shift-1",
      date,
      shift: "DAY",
      origin: "REINFORCEMENT",
      state: "OPEN",
      openedAt: now.toISOString(),
      expiresAt: "2026-10-15T06:00:00Z",
      widenedAt: now.toISOString(),
      closedAt: null,
      need: { required: 1, kept: 0, missingHeadcount: 1, missingQualifications: [] },
    });
    state.callRecipients.push({ callId: "call-1", userId: julien, circle: "WIDENED" });
    state.callProposals.push({
      id: "proposal-1",
      callId: "call-1",
      userId: julien,
      state: "SELECTED",
      proposedAt: now.toISOString(),
      declared: true,
    });
    const after = coverage(state, campaignId, date, "DAY", "planned");
    expect(after.invalid.map(a => a.id)).not.toContain(julien);
    expect(after.covered).toBe(true);
  });
});

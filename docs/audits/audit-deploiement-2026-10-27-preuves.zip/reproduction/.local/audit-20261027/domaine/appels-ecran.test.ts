import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it, vi } from "vitest";
import { buildState, type Raw } from "@/lib/data-mapping";

// Audit du 27 octobre 2026 — un appel expiré (garde commencée) encore montré « En cours ».
const app = { state: null as unknown, actor: { id: "u3", role: "AGENT" }, run: vi.fn() };
vi.mock("@/components/provider", () => ({ useApp: () => app }));

const raw: Raw = {
  organization: { name: "CIS", day_start: 8, night_start: 20 },
  members: [
    { user_id: "u3", role: "AGENT", team_id: "t1", active: true, profiles: { display_name: "Agent Trois" }, teams: { name: "A" } },
  ],
  teams: [{ id: "t1", name: "A" }],
  qualificationCatalogue: [],
  template: [],
  invitations: [],
  memberQualifications: [],
  notifications: [],
  campaigns: [
    {
      id: "c1",
      name: "Novembre",
      team_id: "t1",
      starts_on: "2026-11-01",
      opens_at: "2026-10-01T06:00:00+00:00",
      closes_at: "2026-10-31T22:59:59+00:00",
      locked: false,
      day_start: 8,
      night_start: 20,
    },
  ],
  participants: [{ campaign_id: "c1", user_id: "u3", validated_at: "2026-10-15T09:00:00+00:00" }],
  entries: [],
  requirements: [],
  schedules: [{ id: "sch1", campaign_id: "c1" }],
  withdrawals: [],
  shifts: [{ id: "s1", schedule_id: "sch1", date: "2026-11-03", shift_code: "NIGHT", published_revision: 1, published_at: "2026-10-20T08:00:00+00:00" }],
  // La garde du 3 novembre, Nuit, commence à 20 h à Paris = 19:00Z : expires_at. Nous sommes le 3 novembre à 20 h 02.
  calls: [
    {
      id: "call-1",
      campaign_id: "c1",
      schedule_shift_id: "s1",
      date: "2026-11-03",
      shift_code: "NIGHT",
      origin: "REINFORCEMENT",
      state: "OPEN",
      opened_at: "2026-11-01T08:00:00+00:00",
      expires_at: "2026-11-03T19:00:00+00:00",
      widened_at: null,
      closed_at: null,
      need: { required: 2, kept: 1, missing_headcount: 1, missing_qualifications: [] },
    },
  ],
  callRecipients: [{ call_id: "call-1", user_id: "u3", circle: "AVAILABLE" }],
  calendarFeeds: [],
  callProposals: [],
  assignments: [],
  audit: [],
};

describe("Écran Appels", () => {
  it("CONSTAT : à 20 h 02, l'appel de la garde de 20 h (expires_at 19:00Z dépassé) est encore listé sous « Gardes à pourvoir »", async () => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date("2026-11-03T19:02:00Z"));
    app.state = buildState(raw, "CIS");
    const { Calls } = await import("@/components/calls");
    const html = renderToStaticMarkup(createElement(Calls));
    vi.useRealTimers();
    // Attendu : plus d'appel en cours (la base répond « This call is closed » à qui se propose).
    expect(html).toContain("Aucun appel en cours");
  });
});

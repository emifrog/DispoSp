// Lot C — appels à remplacement et à renfort (20261021090000_appels_remplacement.sql).
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { centre, type Centre } from "./fixture";

const withdraw = (c: Centre, who: string, shift: string) =>
  c.as<{ id: string }>(
    who,
    "insert into public.shift_withdrawals(organization_id,schedule_shift_id,user_id,reason) values ($1,$2,$3,'Motif privé') returning id",
    [c.org, shift, who],
  );
const recipients = (c: Centre, call: string) =>
  c.rows<{ user_id: string; circle: string }>(
    "select user_id, circle from public.call_recipients where call_id=$1 order by user_id",
    [call],
  );

// call_candidates() (L735-770) n'écarte que `leaving`, l'agent du désistement
// passé à open_call(). Un agent dont le désistement sur CE créneau a été accepté
// autrement — acceptation simple depuis l'écran, ou appel précédent — redevient
// candidat dès qu'il n'est plus au brouillon. Spécification §7, L359 : « Ne pas
// solliciter automatiquement l'agent dont le désistement vient d'être accepté
// pour reprendre sa propre garde. »
describe("Lot C — l'agent dont le désistement a été accepté est sollicité pour sa propre garde", () => {
  let c: Centre;
  let a1: string, a2: string, a3: string;
  beforeAll(async () => {
    c = await centre({ prefix: "a", agents: 4, available: [1, 2, 3], need: 2 });
    [a1, a2, a3] = c.agents;
  });
  afterAll(async () => {
    await c.db.close();
  });

  it("acceptation simple, retrait du brouillon, puis « Chercher du renfort » : l'agent désisté est sollicité", async () => {
    const shift = c.slot(2, "D");
    await c.publish(shift, [a1, a2]);
    const [w] = await withdraw(c, a1, shift);
    // L'écran « Désistements », bouton Accepter : decideWithdrawal() ne fait que
    // ceci (src/lib/commands.server.ts:450-459).
    await c.as(c.chef, "update public.shift_withdrawals set state='ACCEPTED' where id=$1", [w.id]);
    expect(await c.rows("select state from public.shift_withdrawals where id=$1", [w.id])).toEqual([{ state: "ACCEPTED" }]);
    // Le gestionnaire retire l'agent du brouillon : le blocage « withdrawal »
    // (L300-308) l'y oblige avant toute republication.
    await c.as(c.chef, "delete from public.schedule_assignments where schedule_shift_id=$1 and user_id=$2 and revision=0", [
      shift,
      a1,
    ]);
    const preview = await c.one<{ p: { need: Record<string, unknown>; available: number } }>(
      c.chef,
      "select public.call_preview($1) as p",
      [shift],
    );
    expect(preview.p.need).toMatchObject({ required: 2, kept: 1, missing_headcount: 1 });
    // Attendu : Trois seul. Un s'est désisté, Deux est conservé, Quatre n'a pas
    // de disponibilité validée.
    expect(preview.p.available).toBe(1);
    const call = (await c.one<{ id: string }>(c.chef, "select public.open_call($1) as id", [shift])).id;
    expect((await recipients(c, call)).map(r => r.user_id)).toEqual([a3]);
    expect(await c.count("public.notifications", "where kind='CALL_OPENED' and user_id=$1", [a1])).toBe(0);
  });

  it("« Accepter et chercher un remplaçant », appel annulé, puis « Chercher du renfort » : l'agent désisté est sollicité", async () => {
    const shift = c.slot(3, "D");
    await c.publish(shift, [a1, a2]);
    const [w] = await withdraw(c, a1, shift);
    const first = (await c.one<{ id: string }>(c.chef, "select public.open_call($1, $2) as id", [shift, w.id])).id;
    // Ici, Un est bien écarté : il est `leaving`.
    expect((await recipients(c, first)).map(r => r.user_id)).toEqual([a3]);
    await c.as(c.chef, "select public.cancel_call($1)", [first]);
    // Nouvel épisode sur la même garde : Un n'est plus au brouillon (open_call
    // L877 l'en a retiré) et n'est plus `leaving`.
    const second = (await c.one<{ id: string }>(c.chef, "select public.open_call($1) as id", [shift])).id;
    expect((await recipients(c, second)).map(r => r.user_id)).toEqual([a3]);
  });
});

describe("Lot C — fermeture par la publication du mois, et lecture sous RLS", () => {
  let c: Centre;
  let other: Centre;
  let a1: string, a2: string, a3: string, a4: string;
  beforeAll(async () => {
    c = await centre({ prefix: "b", agents: 4, available: [1, 2, 3], need: 2 });
    other = await centre({ prefix: "c", agents: 1, db: c.db });
    [a1, a2, a3, a4] = c.agents;
  });
  afterAll(async () => {
    await c.db.close();
  });

  it("une publication du mois résout l'appel ouvert et confirme les propositions retenues", async () => {
    const shift = c.slot(2, "D");
    const call = (await c.one<{ id: string }>(c.chef, "select public.open_call($1) as id", [shift])).id;
    expect((await recipients(c, call)).map(r => r.user_id)).toEqual([a1, a2, a3]);
    for (const who of [a1, a3]) await c.as(who, "select public.propose_for_call($1, false, null)", [call]);
    for (const who of [a1, a3])
      await c.as(c.chef, "select public.select_proposal((select id from public.call_proposals where call_id=$1 and user_id=$2))", [
        call,
        who,
      ]);
    const preview = await c.one<{ p: { fingerprint: string; counts: { ready: number } } }>(
      c.chef,
      "select public.month_publication_preview($1) as p",
      [c.campaign],
    );
    expect(preview.p.counts.ready).toBe(1);
    const result = await c.one<{ r: { published: number } }>(c.chef, "select public.publish_month($1, $2, $3) as r", [
      c.campaign,
      preview.p.fingerprint,
      "90000000-0000-0000-0000-00000000000b",
    ]);
    expect(result.r.published).toBe(1);
    expect(await c.rows("select state, resolved_revision from public.shift_calls where id=$1", [call])).toEqual([
      { state: "RESOLVED", resolved_revision: 1 },
    ]);
    expect(
      await c.rows("select user_id, state from public.call_proposals where call_id=$1 order by user_id", [call]),
    ).toEqual([
      { user_id: a1, state: "CONFIRMED" },
      { user_id: a3, state: "CONFIRMED" },
    ]);
  });

  it("un agent non sollicité ne voit pas l'appel ; un sollicité ne voit que sa ligne et ses propositions ; un autre centre et anon, rien", async () => {
    const shift = c.slot(3, "D");
    const call = (await c.one<{ id: string }>(c.chef, "select public.open_call($1) as id", [shift])).id;
    await c.as(a1, "select public.propose_for_call($1, false, null)", [call]);
    expect(await c.as(a4, "select count(*)::int as n from public.shift_calls")).toEqual([{ n: 0 }]);
    expect(await c.as(a2, "select user_id from public.call_recipients where call_id=$1", [call])).toEqual([{ user_id: a2 }]);
    expect(await c.as(a2, "select count(*)::int as n from public.call_proposals")).toEqual([{ n: 0 }]);
    for (const table of ["shift_calls", "call_recipients", "call_proposals", "calendar_feeds"])
      expect(await c.as(other.chef, `select count(*)::int as n from public.${table}`), table).toEqual([{ n: 0 }]);
    // calendar_feeds n'est lisible que colonne par colonne (L56) : has_any_column_privilege.
    expect(
      await c.rows(`select t, has_any_column_privilege('anon', 'public.' || t, 'select') as anon,
                           has_any_column_privilege('authenticated', 'public.' || t, 'select') as auth,
                           has_any_column_privilege('authenticated', 'public.' || t, 'insert, update') as write,
                           has_table_privilege('authenticated', 'public.' || t, 'delete') as del
                      from unnest(array['shift_calls','call_recipients','call_proposals','calendar_feeds']) t`),
    ).toEqual(
      ["shift_calls", "call_recipients", "call_proposals", "calendar_feeds"].map(t => ({
        t,
        anon: false,
        auth: true,
        write: false,
        del: false,
      })),
    );
  });

  it("un appel annulé avertit le retenu « non retenue » mais le laisse au brouillon", async () => {
    const shift = c.slot(4, "D");
    const call = (await c.one<{ id: string }>(c.chef, "select public.open_call($1) as id", [shift])).id;
    await c.as(a2, "select public.propose_for_call($1, false, null)", [call]);
    await c.as(c.chef, "select public.select_proposal((select id from public.call_proposals where call_id=$1 and user_id=$2))", [
      call,
      a2,
    ]);
    await c.as(c.chef, "select public.cancel_call($1)", [call]);
    expect(await c.rows("select state from public.call_proposals where call_id=$1 and user_id=$2", [call, a2])).toEqual([
      { state: "DECLINED" },
    ]);
    expect(await c.count("public.notifications", "where kind='CALL_CLOSED' and user_id=$1", [a2])).toBe(1);
    // Deux sort du brouillon avec sa proposition déclinée.
    expect(await c.rows("select user_id from public.schedule_assignments where schedule_shift_id=$1 and revision=0", [shift])).toEqual([]);
  });
});

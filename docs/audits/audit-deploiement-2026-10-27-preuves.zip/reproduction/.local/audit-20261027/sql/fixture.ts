// Un centre d'essai complet, pour les reproductions de l'audit du 27 octobre 2026.
// slot(d, "D"|"N") est le créneau du jour d du mois de la campagne.
import type { PGlite } from "@electric-sql/pglite";
import { freshDatabase } from "../../../tests/fixtures/schema";

export type Code = "D" | "N";
export const TERMS = "declaration-2026-10-21";
export type Centre = {
  db: PGlite;
  org: string;
  team: string;
  admin: string;
  chef: string;
  agents: string[];
  campaign: string;
  schedule: string;
  qual: string;
  email: (id: string) => string;
  slot: (day: number, code: Code) => string;
  rows: <T = Record<string, unknown>>(sql: string, params?: unknown[]) => Promise<T[]>;
  as: <T = Record<string, unknown>>(id: string, sql: string, params?: unknown[]) => Promise<T[]>;
  one: <T = Record<string, unknown>>(id: string, sql: string, params?: unknown[]) => Promise<T>;
  publish: (shift: string, users: string[], revision?: number) => Promise<void>;
  count: (table: string, where?: string, params?: unknown[]) => Promise<number>;
};

export async function centre(opts: {
  prefix: string; // un chiffre hexadécimal, distinct par centre d'une même base
  agents: number;
  available?: number[]; // indices (à partir de 1) des agents avec une disponibilité 24 h validée sur tout le mois
  need?: number;
  startsOn?: string; // 'AAAA-MM-01' ; sinon le mois prochain
  name?: string;
  days?: number;
  db?: PGlite;
}): Promise<Centre> {
  const p = opts.prefix;
  const db = opts.db ?? (await freshDatabase());
  const id = (kind: string, n: number) => `${kind}${p}000000-0000-0000-0000-${String(n).padStart(12, "0")}`;
  const org = id("1", 1);
  const team = id("2", 1);
  const campaign = id("4", 1);
  const schedule = id("5", 1);
  const qual = id("7", 1);
  const admin = id("3", 0);
  const chef = id("3", 1);
  const agents = Array.from({ length: opts.agents }, (_, i) => id("3", 11 + i));
  const emails = new Map<string, string>([
    [admin, `admin@${p}.test`],
    [chef, `chef@${p}.test`],
    ...agents.map((a, i) => [a, `agent${i + 1}@${p}.test`] as [string, string]),
  ]);
  const slot = (day: number, code: Code) =>
    `6${p}000000-0000-0000-0000-000000000${code === "D" ? "d" : "e"}${String(day).padStart(2, "0")}`;
  const available = (opts.available ?? agents.map((_, i) => i + 1)).map(i => agents[i - 1]);
  const start = opts.startsOn
    ? `'${opts.startsOn}'::date`
    : `date_trunc('month', (now() at time zone 'Europe/Paris')::date + interval '1 month')::date`;
  const days = opts.days ?? 7;
  const need = opts.need ?? 2;
  const users = [admin, chef, ...agents];
  const list = (ids: string[]) => ids.map(u => `'${u}'`).join(",");
  const availabilitySql = available.length
    ? `set session_replication_role = replica;
    insert into public.availability_entries(campaign_id,user_id,date,availability_type)
      select '${campaign}', u, s.date, 'FULL_24H' from unnest(array[${list(available)}]::uuid[]) u,
             (select distinct date from public.schedule_shifts where schedule_id = '${schedule}') s;
    update public.campaign_participants set validated_at = now() - interval '1 hour'
     where campaign_id = '${campaign}' and user_id in (${list(available)});
    set session_replication_role = origin;`
    : "";
  await db.exec(`
    insert into auth.users(id,email,email_confirmed_at) values ${users.map(u => `('${u}','${emails.get(u)}',now())`).join(", ")};
    insert into public.profiles(user_id,display_name) values ('${admin}','Admin ${p}'), ('${chef}','Chef ${p}'),
      ${agents.map((a, i) => `('${a}','Agent ${i + 1}')`).join(", ")};
    insert into public.organizations(id,name) values ('${org}','${opts.name ?? `Centre ${p}`}');
    insert into public.teams(id,organization_id,name) values ('${team}','${org}','Alpha');
    insert into public.memberships values ('${org}','${admin}','${team}','ADMIN',true), ('${org}','${chef}','${team}','GESTIONNAIRE',true),
      ${agents.map(a => `('${org}','${a}','${team}','AGENT',true)`).join(", ")};
    insert into public.qualifications(id,organization_id,name) values ('${qual}','${org}','INC1');
    insert into public.availability_campaigns(id,organization_id,team_id,name,starts_on,ends_on,opens_at,closes_at)
      select '${campaign}','${org}','${team}','Campagne ${p}', m, (m + interval '1 month - 1 day')::date,
             now()-interval '10 days', now()+interval '1 day'
        from (select ${start} as m) t;
    insert into public.campaign_participants(organization_id,campaign_id,user_id) values
      ${agents.map(a => `('${org}','${campaign}','${a}')`).join(", ")};
    insert into public.schedules(id,organization_id,campaign_id,team_id) values ('${schedule}','${org}','${campaign}','${team}');
    insert into public.schedule_shifts(id,organization_id,schedule_id,date,shift_code)
      select ('6${p}000000-0000-0000-0000-000000000' || case when code = 'DAY' then 'd' else 'e' end || lpad(d::text, 2, '0'))::uuid,
             '${org}', '${schedule}', c.starts_on + (d - 1), code
        from public.availability_campaigns c, generate_series(1, ${days}) d, unnest(array['DAY','NIGHT']) code
       where c.id = '${campaign}';
    insert into public.staffing_requirements(organization_id,campaign_id,date,shift_code,headcount)
      select '${org}', '${campaign}', s.date, s.shift_code, ${need} from public.schedule_shifts s where s.schedule_id = '${schedule}';
    ${availabilitySql}`);
  const rows = async <T>(sql: string, params: unknown[] = []) => {
    await db.exec("reset role");
    return (await db.query<T>(sql, params)).rows;
  };
  const as = async <T>(who: string, sql: string, params: unknown[] = []) => {
    await db.exec("reset role");
    await db.query("select set_config('request.jwt.claim.sub', $1, false)", [who]);
    await db.exec("set role authenticated");
    try {
      return (await db.query<T>(sql, params)).rows;
    } finally {
      await db.exec("reset role");
    }
  };
  const one = async <T>(who: string, sql: string, params: unknown[] = []) => (await as<T>(who, sql, params))[0];
  const publish = async (shift: string, members: string[], revision = 1) => {
    await db.exec("reset role");
    const inserts = members
      .map(
        u => `insert into public.schedule_assignments(organization_id,schedule_shift_id,user_id,revision,status,assigned_by)
                values ('${org}','${shift}','${u}',0,'PROPOSED','${chef}') on conflict do nothing;
              insert into public.schedule_assignments(organization_id,schedule_shift_id,user_id,revision,status,assigned_by)
                values ('${org}','${shift}','${u}',${revision},'CONFIRMED','${chef}');`,
      )
      .join("\n");
    await db.exec(`set session_replication_role = replica;
      ${inserts}
      update public.schedule_shifts set published_revision=${revision}, published_at=now()-interval '1 day' where id='${shift}';
      set session_replication_role = origin;`);
  };
  const count = async (table: string, where = "", params: unknown[] = []) =>
    Number((await rows<{ n: number }>(`select count(*)::int as n from ${table} ${where}`, params))[0].n);
  return {
    db,
    org,
    team,
    admin,
    chef,
    agents,
    campaign,
    schedule,
    qual,
    slot,
    rows,
    as,
    one,
    publish,
    count,
    email: (who: string) => emails.get(who)!,
  };
}

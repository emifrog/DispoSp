// Lot D — agenda abonné (20261021150000_agenda_abonne.sql) : fenêtre −3/+12 mois,
// version remplacée, désistement accepté.
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { centre, type Centre } from "./fixture";

describe("Agenda abonné — fenêtre et gardes encore tenues", () => {
  let c: Centre;
  let agent: string, other: string;
  const extra = (n: number) => `60000000-0000-0000-0000-0000000000a${n}`;
  const feed = async (hash: string) => {
    await c.db.exec("reset role; set role service_role");
    try {
      return (await c.db.query<{ f: { events: { date: string; revision: number }[] } | null }>("select public.calendar_feed_events($1) as f", [hash])).rows[0].f;
    } finally {
      await c.db.exec("reset role");
    }
  };
  beforeAll(async () => {
    c = await centre({ prefix: "d", agents: 2 });
    [agent, other] = c.agents;
    await c.db.exec(`
      insert into public.schedule_shifts(id,organization_id,schedule_id,date,shift_code)
        select ('${extra(0).slice(0, -1)}' || n)::uuid, '${c.org}', '${c.schedule}',
               ((now() at time zone 'Europe/Paris')::date + off)::date, 'DAY'
          from unnest(array[1,2,3,4,5], array['-4 months','-2 months','+11 months','+13 months','-1 day']::interval[]) as t(n, off);`);
    await c.publish(extra(1), [agent]);
    await c.publish(extra(2), [agent]);
    await c.publish(extra(3), [agent]);
    await c.publish(extra(4), [agent]);
    // Hier : publié pour l'agent (version 1), puis remplacé par une version sans lui.
    await c.publish(extra(5), [agent], 1);
    await c.publish(extra(5), [other], 2);
    // Le 1er du mois prochain : publié, puis désistement accepté après la publication.
    await c.publish(c.slot(1, "D"), [agent]);
    await c.publish(c.slot(2, "D"), [agent]);
    await c.db.exec(`set session_replication_role = replica;
      insert into public.shift_withdrawals(organization_id,schedule_shift_id,user_id,state,decided_at,decided_by)
        values ('${c.org}','${c.slot(2, "D")}','${agent}','ACCEPTED',now(),'${c.chef}');
      set session_replication_role = origin;`);
    await c.as(agent, "select public.create_calendar_feed($1)", ["7".repeat(64)]);
  });
  afterAll(async () => {
    await c.db.close();
  });

  it("rend les gardes de −3 à +12 mois, sans la version remplacée ni la garde relevée", async () => {
    const f = await feed("7".repeat(64));
    const dates = await c.rows<{ id: string; date: string }>("select id, date::text from public.schedule_shifts where id = any($1)", [
      [extra(2), extra(3), c.slot(1, "D")],
    ]);
    expect(f?.events.map(e => e.date).sort()).toEqual(dates.map(d => d.date).sort());
  });
});

// Droits, idempotence et photographies des six migrations.
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { centre, type Centre } from "./fixture";

const NEW_PRIVATE = [
  "record_reminder_settings", "french_day", "held_shifts", "generate_shift_reminders", "generate_campaign_reminders",
  "cancel_obsolete_notifications", "generate_due_notifications", "shift_bounds", "photograph_publication",
  "photograph_closures", "photograph_shift_starts", "take_due_snapshots", "photograph_before_change", "shift_blockers",
  "publish_shift_version", "month_preview", "french_month", "rest_violation", "shift_text", "kept_team", "call_need",
  "call_candidates", "notify_call", "close_call", "declaration_terms", "release_proposal", "resolve_calls", "expire_calls",
  "lock_members",
];
const NEW_PUBLIC: Record<string, boolean> = {
  // nom → exécutable par authenticated
  cancel_obsolete_notifications: false,
  record_scheduled_run: false,
  scheduled_status: true,
  claim_email_deliveries: false,
  claim_push_deliveries: false,
  month_publication_preview: true,
  publish_month: true,
  call_preview: true,
  open_call: true,
  widen_call: true,
  cancel_call: true,
  propose_for_call: true,
  withdraw_proposal: true,
  select_proposal: true,
  confirm_call: true,
  create_calendar_feed: true,
  revoke_calendar_feed: true,
  calendar_feed_events: false,
};

describe("Droits des fonctions et des tables nouvelles", () => {
  let c: Centre;
  beforeAll(async () => {
    c = await centre({ prefix: "1", agents: 2 });
  });
  afterAll(async () => {
    await c.db.close();
  });

  it("aucune fonction private nouvelle n'est exécutable par anon ni par authenticated", async () => {
    const rows = await c.rows<{ proname: string; args: string; anon: boolean; auth: boolean }>(
      `select p.proname, pg_get_function_identity_arguments(p.oid) as args,
              has_function_privilege('anon', p.oid, 'execute') as anon,
              has_function_privilege('authenticated', p.oid, 'execute') as auth
         from pg_proc p join pg_namespace n on n.oid = p.pronamespace
        where n.nspname = 'private' and p.proname = any($1) order by 1, 2`,
      [NEW_PRIVATE],
    );
    expect(rows.length).toBeGreaterThanOrEqual(NEW_PRIVATE.length);
    expect(rows.filter(r => r.anon || r.auth)).toEqual([]);
  });

  it("les fonctions public nouvelles sont ouvertes à authenticated exactement quand il le faut, jamais à anon", async () => {
    const rows = await c.rows<{ proname: string; anon: boolean; auth: boolean }>(
      `select p.proname, bool_or(has_function_privilege('anon', p.oid, 'execute')) as anon,
              bool_or(has_function_privilege('authenticated', p.oid, 'execute')) as auth
         from pg_proc p join pg_namespace n on n.oid = p.pronamespace
        where n.nspname = 'public' and p.proname = any($1) group by 1 order by 1`,
      [Object.keys(NEW_PUBLIC)],
    );
    expect(rows.map(r => r.proname).sort()).toEqual(Object.keys(NEW_PUBLIC).sort());
    expect(rows.filter(r => r.anon)).toEqual([]);
    expect(Object.fromEntries(rows.map(r => [r.proname, r.auth]))).toEqual(NEW_PUBLIC);
  });

  it("toute fonction « security definer » des deux schémas fixe search_path", async () => {
    expect(
      await c.rows(
        `select n.nspname || '.' || p.proname as f from pg_proc p join pg_namespace n on n.oid = p.pronamespace
          where n.nspname in ('private','public') and p.prosecdef
            and not exists (select 1 from unnest(coalesce(p.proconfig, '{}')) x where x like 'search_path=%')`,
      ),
    ).toEqual([]);
  });

  it("les tables private des lots sont fermées aux sessions ; calendar_feeds cache token_hash", async () => {
    expect(
      await c.rows(
        `select t from unnest(array['history_start','publication_facts','publication_assignees','closure_facts',
                                    'closure_participants','shift_start_facts','campaign_auto_reminders','scheduled_runs',
                                    'month_publications']) t
          where has_table_privilege('authenticated', 'private.' || t, 'select') or has_table_privilege('anon', 'private.' || t, 'select')`,
      ),
    ).toEqual([]);
    expect(
      await c.rows(
        `select has_column_privilege('authenticated', 'public.calendar_feeds', 'token_hash', 'select') as hash,
                has_column_privilege('authenticated', 'public.calendar_feeds', 'user_id', 'select') as user_id`,
      ),
    ).toEqual([{ hash: false, user_id: true }]);
  });
});

describe("Photographies et passage planifié — une fois par transaction, rejouables", () => {
  let c: Centre;
  beforeAll(async () => {
    c = await centre({ prefix: "2", agents: 2 });
    await c.db.exec(`update private.history_start set started_at = '2026-01-01';
      update public.availability_campaigns set closes_at = now() - interval '1 minute' where id = '${c.campaign}';`);
  });
  afterAll(async () => {
    await c.db.close();
  });

  it("dans une transaction, la seconde modification du même centre ne reprend rien", async () => {
    await c.db.exec("begin");
    try {
      const take = async (org: string | null) =>
        (await c.db.query<{ r: Record<string, number> }>("select private.take_due_snapshots(now(), $1, 'modification') as r", [org])).rows[0].r;
      expect(await take(c.org)).toEqual({ clotures: 1, debuts: 0 });
      expect(await take(c.org)).toEqual({});
      expect(await take(null)).toEqual({ clotures: 0, debuts: 0 });
      expect(await take(c.org)).toEqual({});
    } finally {
      await c.db.exec("commit");
    }
    expect(await c.count("private.closure_facts")).toBe(1);
  });

  it("le passage planifié rejoué ne crée rien de plus", async () => {
    const generate = async () =>
      (await c.rows<{ r: Record<string, unknown> }>("select private.generate_due_notifications(now()) as r"))[0].r;
    await generate();
    expect(await generate()).toEqual({
      photographies: { clotures: 0, debuts: 0 },
      appels_expires: 0,
      annulations: 0,
      rappels_de_garde: 0,
      relances: 0,
    });
  });
});

// Les scripts de provisionnement face aux tables des lots B, C et D :
// shift_calls, call_recipients, call_proposals, calendar_feeds, private.month_publications.
// tests/provisioning.test.ts et les blocs « Retrait d'un compte » de
// tests/database.test.ts ne peuplent aucune de ces tables.
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { provisioningScript } from "../../../tests/fixtures/schema";
import { centre, TERMS, type Centre } from "./fixture";

/** Un centre où les lots C et D ont servi : un appel résolu, un appel ouvert, deux abonnements, une demande de mois. */
async function populate(c: Centre) {
  const [a1, a2, a3, a4] = c.agents;
  const shift = c.slot(2, "D");
  await c.publish(shift, [a1, a2]);
  const [w] = await c.as<{ id: string }>(
    a1,
    "insert into public.shift_withdrawals(organization_id,schedule_shift_id,user_id,reason) values ($1,$2,$3,'Motif') returning id",
    [c.org, shift, a1],
  );
  const resolved = (await c.one<{ id: string }>(c.chef, "select public.open_call($1, $2) as id", [shift, w.id])).id;
  await c.as(c.chef, "select public.widen_call($1)", [resolved]);
  await c.as(a3, "select public.propose_for_call($1, false, null)", [resolved]);
  await c.as(a4, "select public.propose_for_call($1, true, $2)", [resolved, TERMS]);
  await c.as(
    c.chef,
    "select public.select_proposal((select id from public.call_proposals where call_id=$1 and user_id=$2))",
    [resolved, a3],
  );
  await c.as(c.chef, "select public.confirm_call($1)", [resolved]);
  const open = (await c.one<{ id: string }>(c.chef, "select public.open_call($1) as id", [c.slot(3, "D")])).id;
  await c.as(c.chef, "select public.widen_call($1)", [open]);
  await c.as(a4, "select public.propose_for_call($1, true, $2)", [open, TERMS]);
  await c.as(
    c.chef,
    "select public.select_proposal((select id from public.call_proposals where call_id=$1 and user_id=$2))",
    [open, a4],
  );
  await c.as(a3, "select public.create_calendar_feed($1)", ["3".repeat(64)]);
  await c.as(a4, "select public.create_calendar_feed($1)", ["4".repeat(64)]);
  await c.db.exec(`insert into private.month_publications(request_id,organization_id,campaign_id,result)
    values ('90000000-0000-0000-0000-000000000001','${c.org}','${c.campaign}','{"published":1}')`);
  expect(await c.rows("select state from public.shift_calls order by opened_at")).toEqual([
    { state: "RESOLVED" },
    { state: "OPEN" },
  ]);
  expect(await c.count("public.call_recipients")).toBe(6);
  expect(await c.count("public.call_proposals")).toBe(3);
  expect(await c.count("public.calendar_feeds")).toBe(2);
  return { resolved, open };
}

describe("retirer-un-compte.sql — comptes présents dans les tables des lots C et D", () => {
  let c: Centre;
  let a3: string, a4: string;
  let calls: { resolved: string; open: string };
  // Comme dans l'éditeur SQL du tableau de bord : aucune session, auth.uid() nul.
  const retirer = async (email: string) => {
    await c.db.exec("reset role; select set_config('request.jwt.claim.sub', '', false)");
    await c.db.exec(provisioningScript("retirer-un-compte.sql").replace("'agent.qui.part@exemple.fr'", `'${email}'`));
  };
  const traces = (who: string) =>
    c.rows<{ t: string; n: number }>(
      `select 'call_recipients' as t, count(*)::int as n from public.call_recipients where user_id=$1
       union all select 'call_proposals', count(*) from public.call_proposals where user_id=$1
       union all select 'calendar_feeds', count(*) from public.calendar_feeds where user_id=$1
       union all select 'schedule_assignments', count(*) from public.schedule_assignments where user_id=$1
       union all select 'memberships', count(*) from public.memberships where user_id=$1
       union all select 'publication_assignees', count(*) from private.publication_assignees where user_id=$1`,
      [who],
    );
  beforeAll(async () => {
    c = await centre({ prefix: "f", agents: 4, available: [1, 2, 3], need: 2 });
    [, , a3, a4] = c.agents;
    calls = await populate(c);
  });
  afterAll(async () => {
    await c.db.close();
  });

  it("retire un agent sollicité deux fois, retenu au brouillon d'un appel ouvert et abonné à l'agenda", async () => {
    await retirer(c.email(a4));
    expect((await traces(a4)).filter(r => Number(r.n) !== 0)).toEqual([]);
    await c.db.query("delete from auth.users where id=$1", [a4]);
    // L'appel ouvert reste ouvert, sans lui.
    expect(await c.rows("select state from public.shift_calls where id=$1", [calls.open])).toEqual([{ state: "OPEN" }]);
  });

  it("retire un agent publié par un appel : proposition confirmée, photographie de publication", async () => {
    await retirer(c.email(a3));
    expect((await traces(a3)).filter(r => Number(r.n) !== 0)).toEqual([]);
    await c.db.query("delete from auth.users where id=$1", [a3]);
  });

  it("retire le gestionnaire qui a ouvert, fermé et tranché, puis laisse supprimer son compte", async () => {
    await retirer(c.email(c.chef));
    expect(await c.count("public.memberships", "where user_id=$1", [c.chef])).toBe(0);
    await c.db.query("delete from auth.users where id=$1", [c.chef]);
    expect(await c.rows("select opened_by, closed_by from public.shift_calls where id=$1", [calls.resolved])).toEqual([
      { opened_by: null, closed_by: null },
    ]);
    expect(await c.count("public.call_proposals", "where decided_by is not null")).toBe(0);
  });
});

describe("basculer-vers-un-vrai-centre.sql — un centre d'essai qui a servi aux lots C et D", () => {
  let c: Centre;
  beforeAll(async () => {
    c = await centre({ prefix: "9", agents: 4, available: [1, 2, 3], need: 2, name: "CIS Test" });
    await populate(c);
  });
  afterAll(async () => {
    await c.db.close();
  });

  it("efface le centre d'essai, appels, destinataires, propositions, abonnements et demandes de mois compris", async () => {
    await c.db.exec("reset role; select set_config('request.jwt.claim.sub', '', false)");
    await c.db.exec(
      provisioningScript("basculer-vers-un-vrai-centre.sql")
        .replace("'administrateur@exemple.fr'", `'${c.email(c.admin)}'`)
        .replace("array['agent.de.recette@exemple.fr']", "array[]::text[]"),
    );
    expect(await c.count("public.organizations", "where name='CIS Test'")).toBe(0);
    for (const table of [
      "public.shift_calls",
      "public.call_recipients",
      "public.call_proposals",
      "public.calendar_feeds",
      "private.month_publications",
      "private.publication_facts",
      "private.shift_start_facts",
      "private.closure_facts",
    ])
      expect(await c.count(table), table).toBe(0);
    expect(await c.count("public.memberships")).toBe(1);
  });
});

describe("purger-les-donnees-anciennes.sql — appels et abonnements anciens", () => {
  let c: Centre;
  const old = "40000000-0000-0000-0000-00000000aa01";
  const oldSchedule = "50000000-0000-0000-0000-00000000aa01";
  const oldShift = "60000000-0000-0000-0000-00000000aa01";
  const oldCall = "80000000-0000-0000-0000-00000000aa01";
  beforeAll(async () => {
    c = await centre({ prefix: "8", agents: 2, need: 2 });
    const [a1] = c.agents;
    await c.db.exec(`
      insert into public.availability_campaigns(id,organization_id,team_id,name,starts_on,ends_on,opens_at,closes_at,locked)
        values ('${old}','${c.org}','${c.team}','Ancienne','2023-01-01','2023-01-31','2022-12-01','2022-12-31',true);
      insert into public.schedules(id,organization_id,campaign_id,team_id) values ('${oldSchedule}','${c.org}','${old}','${c.team}');
      insert into public.schedule_shifts(id,organization_id,schedule_id,date,shift_code,published_revision,published_at)
        values ('${oldShift}','${c.org}','${oldSchedule}','2023-01-15','DAY',1,'2023-01-10');
      insert into public.shift_calls(id,organization_id,campaign_id,schedule_shift_id,date,shift_code,origin,need,revision_at_open,expires_at,state,closed_at)
        values ('${oldCall}','${c.org}','${old}','${oldShift}','2023-01-15','DAY','REINFORCEMENT','{}',1,'2023-01-15 07:00+00','EXPIRED','2023-01-15 07:00+00');
      insert into public.call_recipients(call_id,organization_id,user_id,circle) values ('${oldCall}','${c.org}','${a1}','AVAILABLE');
      insert into public.call_proposals(call_id,organization_id,user_id,state) values ('${oldCall}','${c.org}','${a1}','DECLINED');
      insert into public.calendar_feeds(organization_id,user_id,token_hash,revoked_at) values
        ('${c.org}','${a1}','${"a".repeat(64)}',now()-interval '13 months'), ('${c.org}','${a1}','${"b".repeat(64)}',null);`);
    const recent = (await c.one<{ id: string }>(c.chef, "select public.open_call($1) as id", [c.slot(2, "D")])).id;
    await c.as(a1, "select public.propose_for_call($1, false, null)", [recent]);
  });
  afterAll(async () => {
    await c.db.close();
  });

  it("efface l'appel de la campagne ancienne avec ses destinataires et propositions, et l'abonnement révoqué depuis plus d'un an", async () => {
    await c.db.exec("reset role; select set_config('request.jwt.claim.sub', '', false)");
    await c.db.exec(provisioningScript("purger-les-donnees-anciennes.sql"));
    expect(await c.count("public.availability_campaigns", "where id=$1", [old])).toBe(0);
    expect(await c.count("public.shift_calls", "where id=$1", [oldCall])).toBe(0);
    expect(await c.count("public.call_recipients", "where call_id=$1", [oldCall])).toBe(0);
    expect(await c.count("public.call_proposals", "where call_id=$1", [oldCall])).toBe(0);
    expect(await c.count("public.shift_calls")).toBe(1);
    expect(await c.count("public.call_proposals")).toBe(1);
    expect(await c.rows("select token_hash from public.calendar_feeds")).toEqual([{ token_hash: "b".repeat(64) }]);
  });
});

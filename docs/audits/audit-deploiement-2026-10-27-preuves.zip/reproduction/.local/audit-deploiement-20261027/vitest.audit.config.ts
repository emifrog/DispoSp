import { defineConfig } from 'vitest/config';
import { fileURLToPath } from 'node:url';
export default defineConfig({
  resolve: { alias: { '@': fileURLToPath(new URL('../../src', import.meta.url)) } },
  test: {
    include: [
      '.local/audit-20261027/ecrans/couverture-declaration.test.ts',
      '.local/audit-20261027/sql/appels.test.ts',
      '.local/audit-20261027/sql/droits.test.ts',
      '.local/audit-20261027/sql/agenda.test.ts',
      '.local/audit-20261027/sql/provisionnement.test.ts',
      '.local/audit-deploiement-20261027/complements.test.ts',
      '.local/audit-20261027/domaine/appels-ecran.test.ts'
    ],
    pool: 'threads', maxWorkers: 2, testTimeout: 120000, hookTimeout: 120000
  }
});

import {test,expect} from '@playwright/test';
import {writeFileSync} from 'node:fs';
test('mesures des ecrans accessibles au compte administrateur',async({page})=>{
  await page.goto('/connexion');
  await page.getByLabel('Adresse électronique').fill(process.env.E2E_EMAIL!);
  await page.getByLabel('Mot de passe',{exact:true}).fill(process.env.E2E_PASSWORD!);
  await page.getByRole('button',{name:'Se connecter'}).click();
  await expect(page).toHaveURL(/tableau-de-bord/);
  const measurements=[];
  for(const width of [320,390,768,1440]) {
    await page.setViewportSize({width,height:900});
    for(const route of ['/tableau-de-bord','/disponibilites','/planning','/besoins','/demandes','/agents','/campagnes','/statistiques','/historique','/notifications','/parametres','/profil']) {
      await page.goto(route);
      await expect(page.locator('main h1')).toBeVisible();
      await page.waitForFunction(()=>!!document.querySelector('a[aria-current="page"]'));
      await page.evaluate(async()=>{await document.fonts.ready;await new Promise(requestAnimationFrame);});
      const measure=await page.evaluate(()=>({overflow:document.documentElement.scrollWidth-innerWidth,durationMs:Math.round(performance.now()),ttfbMs:Math.round((performance.getEntriesByType('navigation')[0] as PerformanceNavigationTiming).responseStart),outside:[...document.querySelectorAll('main *')].map(el=>({el,box:el.getBoundingClientRect()})).filter(({box})=>box.right>innerWidth+1&&box.width>0).slice(0,12).map(({el,box})=>({tag:el.tagName,classes:el.className,right:Math.round(box.right),width:Math.round(box.width)}))}));
      measurements.push({route,width,...measure});
      if(measure.overflow>1) await page.screenshot({path:`.local/audit-deploiement-20261027/overflow-${route.slice(1)}-${width}.png`,fullPage:true});
      expect.soft(measure.overflow,`${route} ${width}`).toBeLessThanOrEqual(1);
      writeFileSync('.local/audit-deploiement-20261027/mesures-ecrans.json',JSON.stringify(measurements,null,2));
    }
  }
  writeFileSync('.local/audit-deploiement-20261027/mesures-ecrans.json',JSON.stringify(measurements,null,2));
  await page.goto('/connexion');
});

test('contraste du rappel de remplacement',async({page})=>{
  await page.goto('/connexion');
  const ratio=await page.evaluate(()=>{
    const el=document.createElement('p');el.className='withdrawal-todo';el.textContent='Toujours au planning publié — le remplacement reste à faire';document.body.append(el);
    const s=getComputedStyle(el);
    const lum=(c:string)=>{const x=c.match(/\d+/g)!.slice(0,3).map(Number).map(v=>{v/=255;return v<=0.04045?v/12.92:((v+0.055)/1.055)**2.4;});return 0.2126*x[0]+0.7152*x[1]+0.0722*x[2];};
    const a=lum(s.color),b=lum(s.backgroundColor);return (Math.max(a,b)+0.05)/(Math.min(a,b)+0.05);
  });
  console.log('CONTRASTE_RAPPEL',ratio);
  expect(ratio).toBeGreaterThanOrEqual(4.5);
});

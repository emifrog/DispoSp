import {defineConfig,devices} from '@playwright/test';
import {fileURLToPath} from 'node:url';
process.loadEnvFile('.env');
export default defineConfig({
  testDir:'.',testMatch:'rendu.spec.ts',timeout:120000,workers:1,
  outputDir:'./browser-results',
  use:{...devices['Desktop Chrome'],baseURL:'http://127.0.0.1:3000',locale:'fr-FR',timezoneId:'Europe/Paris'},
  webServer:{cwd:fileURLToPath(new URL('../..',import.meta.url)),command:'node node_modules/next/dist/bin/next start --hostname 127.0.0.1',url:'http://127.0.0.1:3000/connexion',reuseExistingServer:true,timeout:60000}
});

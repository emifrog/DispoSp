import { afterAll, beforeAll, describe, expect, it, vi } from 'vitest';
import { createElement } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { freshDatabase, MIGRATIONS } from '../../tests/fixtures/schema';
import { sampleState } from '../../tests/fixtures/centre';
import { visibleCampaigns, type AppState } from '../../src/lib/domain';
import { readdirSync } from 'node:fs';

const context = vi.hoisted(() => ({state: null as unknown, actor:{id:'julien',role:'AGENT'},run:vi.fn()}));
vi.mock('@/components/provider', () => ({useApp:()=>context}));

describe('Catalogue de securite complet', () => {
  let db: Awaited<ReturnType<typeof freshDatabase>>;
  beforeAll(async()=>{db = await freshDatabase();});
  afterAll(async()=>{await db.close();});
  it('charge toutes les migrations presentes',()=>{
    expect([...MIGRATIONS].sort()).toEqual(readdirSync('supabase/migrations').filter(n=>n.endsWith('.sql')).sort());
  });
  it('active RLS sur toutes les tables public et ne les ouvre pas a anon',async()=>{
    const {rows} = await db.query(`select c.relname,c.relrowsecurity,has_table_privilege('anon',c.oid,'select,insert,update,delete') as anon
      from pg_class c join pg_namespace n on n.oid=c.relnamespace where n.nspname='public' and c.relkind='r' order by c.relname`);
    console.log('CATALOGUE_PUBLIC',JSON.stringify(rows));
    expect(rows.length).toBe(26);
    expect(rows.filter((r:any)=>!r.relrowsecurity||r.anon)).toEqual([]);
  });
  it('ferme toutes les tables private aux utilisateurs',async()=>{
    const {rows} = await db.query(`select c.relname,has_table_privilege('anon',c.oid,'select,insert,update,delete') as anon,
      has_table_privilege('authenticated',c.oid,'select,insert,update,delete') as auth
      from pg_class c join pg_namespace n on n.oid=c.relnamespace where n.nspname='private' and c.relkind='r' order by c.relname`);
    console.log('CATALOGUE_PRIVATE',JSON.stringify(rows));
    expect(rows.filter((r:any)=>r.anon||r.auth)).toEqual([]);
  });
});

describe('Agent sollicite sans participation a la campagne',()=>{
  function setup() {
    const state=sampleState(new Date('2026-10-15T10:00:00Z'));
    const campaign=state.campaigns[0];
    for(const c of state.campaigns)c.participants=c.participants.filter(id=>id!=='julien');
    state.calls=[{id:'call-audit',campaignId:campaign.id,shiftId:'shift-audit',date:campaign.month+'-05',shift:'DAY',origin:'REINFORCEMENT',state:'OPEN',openedAt:'2026-10-27T10:00:00Z',expiresAt:'2026-11-05T07:00:00Z',widenedAt:'2026-10-27T10:00:00Z',closedAt:null,need:{required:1,kept:0,missingHeadcount:1,missingQualifications:[]}}];
    state.callRecipients=[{callId:'call-audit',userId:'julien',circle:'WIDENED'}];
    return state;
  }
  it('doit garder le contexte de campagne necessaire pour ouvrir son appel',()=>{
    const state=setup();
    // Le layout renvoie NoCampaign quand cette liste est vide, meme sur /appels.
    expect(visibleCampaigns(state,'julien',false).map(c=>c.id)).toContain(state.calls[0].campaignId);
  });
  it('doit afficher les vrais horaires de la declaration',async()=>{
    const state=setup();
    context.state={...state,campaigns:visibleCampaigns(state,'julien',false)} as AppState;
    const {Calls}=await import('../../src/components/calls');
    const html=renderToStaticMarkup(createElement(Calls));
    expect(html).not.toContain('de 0 h à 0 h');
    expect(html).toContain('de 8 h à 20 h');
  });
});

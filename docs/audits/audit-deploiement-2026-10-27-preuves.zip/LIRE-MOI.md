# Preuves de l'audit DispoSP du 27 octobre 2026

Commit : 07a5526ff31cbe1b8cbc76e5f92bfb07a01f66da.

Les journaux dans resultats/ documentent les controles. Aucun secret, fichier .env ou trace de session navigateur n'est inclus.

Pour rejouer les contre-epreuves, recopier le dossier .local contenu dans reproduction/ a la racine du depot audite, avec ses dependances installees. Les tests SQL utilisent PGlite localement, sans connexion a Supabase.

Commande :

    node node_modules/vitest/vitest.mjs run --config .local/audit-deploiement-20261027/vitest.audit.config.ts

Sur le commit audite : 24 tests, 17 reussites, 7 echecs qui reproduisent les defauts. Ils ne doivent pas etre confondus avec les 608 tests officiels reussis.

Les tests navigateur complementaires necessitent le build et le compte de recette deja configures localement ; aucun identifiant n'est fourni ici. Leur configuration sert la version locale sur 127.0.0.1:3000.
